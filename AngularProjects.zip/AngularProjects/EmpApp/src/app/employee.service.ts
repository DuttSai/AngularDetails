import { Injectable } from '@angular/core';
import { Emp } from './emp';
import {Http,Response} from "@angular/http"
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map'
import 'rxjs/add/operator/catch'
@Injectable()
export class EmployeeService {
emparr:Emp[]=[];
counter:number=0;
  constructor(private http:Http) { }
  addEmp(e:Emp):Observable<Emp[]>{
   return this.http.post("http://localhost:3000/Employee",e).map((response:Response)=><Emp[]>response.json())
  }
  getEmp():Observable<Emp[]>{
  return this.http.get("http://localhost:3000/Employee").map((response:Response)=><Emp[]>response.json())
  }
  removeEmp(id:number):Observable<Emp[]>{
  return this.http.delete("http://localhost:3000/Employee/"+id).map((response:Response)=><Emp[]>response.json()).catch(this.handleError);  
  }
  handleError(error:Response){
    console.error(error)
    return Observable.throw(error)
  }
  updateEmp(e:Emp):Observable<Emp[]>{
    return this.http.put("http://localhost:3000/Employee/"+e.id,e).map((respone:Response)=><Emp[]>respone.json())
  }

}
