import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
import { ProductService } from '../product.service';


@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css'],
  providers:[ProductService]
})
export class ProductComponent implements OnInit {
prod:Product=new Product()
prodarr2:Product[]=[]
  constructor(private productservice:ProductService) { }

  ngOnInit() {
    this.productservice.getDetails().subscribe((productData)=>this.prodarr2=productData)
  }
  showDetails(){
    console.log(JSON.stringify(this.prod))
    this.productservice.addDetails(this.prod)
    this.productservice.getDetails().subscribe((productData)=>this.prodarr2=productData)
    console.log(JSON.stringify(this.prodarr2))
    this.prod=new Product()
  }
  removeTask(id:number){
    this.productservice.removeTask(id).subscribe((productData)=>this.productservice.getDetails().subscribe((productData)=>this.prodarr2=productData),
    (error)=>{
      console.error(error)
    }
    )


  }

}
