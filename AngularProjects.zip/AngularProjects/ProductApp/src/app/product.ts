export class Product {
    productName:string;
    productQty:number;
    id:number;
}
