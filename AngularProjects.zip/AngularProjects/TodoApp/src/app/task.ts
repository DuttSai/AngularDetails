export class Task {
    id:number;
    taskName:string;
    complete:boolean=false;
}
