import { Injectable } from '@angular/core';
import { Product } from './product';
import {Http,Response} from "@angular/http"
import { Observable } from 'rxjs/Observable';
import "rxjs/add/operator/map"
import "rxjs/add/operator/catch"
@Injectable()
export class ProductService {
prodarr1:Product[]=[]
counter:number=0
  constructor(private http:Http) { }
addDetails(p:Product):ProductService{
//   if(!p.productId){
//     p.productId=++this.counter
//   }
// this.prodarr1.push(p)
return this
}
getDetails():Observable<Product[]>{
  return this.http.get("http://localhost:3000/Products").map((response:Response)=><Product[]>response.json())
}
removeTask(id:number):Observable<Product[]>{
  return this.http.delete("http://localhost:3000/Products/"+id).map((response:Response)=><Product[]>response.json()).catch(this.handleError);    
}
handleError(error:Response){
  console.error(error)
  return Observable.throw(error)
}
}
