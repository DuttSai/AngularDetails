import { Component, OnInit } from '@angular/core';
import { Emp } from '../emp';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-emp',
  templateUrl: './emp.component.html',
  styleUrls: ['./emp.component.css'],
  providers:[EmployeeService]
})
export class EmpComponent implements OnInit {
empob:Emp=new Emp()
emparr2:Emp[]=[]

  constructor(private employeeservice:EmployeeService) { }

  ngOnInit() {
    this.employeeservice.getEmp().subscribe((empData)=>this.emparr2=empData);
  }
  disEmp(){
    // console.log(JSON.stringify(this.empob))  
    // this.employeeservice.addEmp(this.empob)
    // this.employeeservice.getEmp().subscribe((empData)=>this.emparr2=empData);
    // console.log(JSON.stringify(this.emparr2))
    // this.empob=new Emp();
    if(!this.empob.id)
    this.employeeservice.addEmp(this.empob).subscribe((data)=>this.employeeservice.getEmp().subscribe((empData)=>this.emparr2=empData))
    else{
      this.employeeservice.updateEmp(this.empob).subscribe((data)=>this.employeeservice.getEmp().subscribe((empData)=>this.emparr2=empData))
    }
    this.empob =new Emp()
  }
  removeEmp(id:number){
    this.employeeservice.removeEmp(id).subscribe((Data)=>this.employeeservice.getEmp().subscribe((empData)=>this.emparr2=empData),
    (error)=>{
      console.log(error)
    }
    );
    
  }
  updateEmp(e:Emp){
    Object.assign(this.empob,e)
    //this.removeEmp(e.empId)
    

  }
}
