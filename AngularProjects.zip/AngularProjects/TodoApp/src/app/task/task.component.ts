import { Component, OnInit } from '@angular/core';
import { Task } from '../task';
import { TodoService } from '../todo.service';

@Component({
  selector: 'app-task',
  templateUrl: './task.component.html',
  styleUrls: ['./task.component.css'],
  providers:[TodoService]
})  
export class TaskComponent implements OnInit {
task:Task=new Task()
taskarr1:Task[]=[]
constructor(private todoservice:TodoService) {

 }

  ngOnInit() {
    this.todoservice.getAllTask().subscribe((taskData)=>this.taskarr1=taskData)
  }
  addTask(task){
    if(!task.id){
    console.log("task added "+ JSON.stringify(task));
    this.todoservice.addTask(task).subscribe((taskData)=>this.todoservice.getAllTask().subscribe((taskData)=>this.taskarr1=taskData))
  }
  else{
    this.todoservice.updateTask(task).subscribe((taskData)=>this.todoservice.getAllTask().subscribe((taskData)=>this.taskarr1=taskData))
  }
  }
  removeTask(id:number){
    this.todoservice.removeTask(id).subscribe((taskData)=>this.todoservice.getAllTask().subscribe((taskData)=>this.taskarr1=taskData),
    (error)=>{
      console.error(error)
    }
    );
    
  }
  updateTask(t:Task){
    Object.assign(this.task,t)

  }
  
}
